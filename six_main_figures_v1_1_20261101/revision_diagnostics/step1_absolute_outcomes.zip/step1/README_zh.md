# 图5绝对验证结果

本次工作完成三策略在阈值选择、同来源验证及留出来源上的绝对结果汇总。所有输入与已归档超算FORMAL输出逐字节一致。没有重新训练、模型推理、阈值选择或bootstrap。新表S11及本次文字修改已黄色高亮，并在数值、结构和逐页排版核验后写回原目录的同名Word文件。原始文件保存在backup目录。

## 文件

- tables/Table_S11a_absolute_all_available.tsv，9行，三政策及三个阶段，各自全部可用实例。
- tables/Table_S11b_absolute_paired_201.tsv，6行，同一201个配对可行实例。
- tables/Table_S11c_absolute_by_model_held_source_phase.tsv，270行，完整政策、模型、留出来源和阶段组合，含117个零可行组合。
- tables/Table_S11d_paired_201_instance_outcomes.tsv，1206行，201实例乘两政策乘三阶段。
- tables/Table_S11e_individual_evaluation_sources.tsv，19800行，逐实例、阶段和评价来源。保留源表的threshold_negative字段，其含义为历史来源阴性标签，不代表实验测定阴性。
- tables/Table_S11f_evaluation_sample_sizes.tsv，18行，各留出来源与阶段的评价记录和依赖组数。
- inputs目录为本次使用的正式冻结输出；input_manifest.json保留SHA256与正式结果核对信息。
- analysis_QA.json及structural_QA.json为数值和Word保留性检查。

## 统计口径

选择集和同来源验证集含五个开发来源。等初始来源权重下，覆盖率为各来源保留比例的均值。设来源记录数n_s，保留记录k_s，保留错误e_s，阳性P_s，保留阳性p_s，则条件混合错误为Σ(e_s/n_s)/Σ(k_s/n_s)，阳性拒绝为Σ((P_s−p_s)/n_s)/Σ(P_s/n_s)。来源保留后的权重与其覆盖比例成正比。留出来源使用一个来源的普通记录比例。

可用实例中的每个实例各贡献一次，不再平衡不同模型或留出来源的可用实例数量。汇总为中位数和线性插值的25%及75%分位数，表示重复划分敏感性，不是置信区间。单独中位数之差不等于配对差值中位数。三政策全部可用实例并不相同，不能把表S11a之间的直接差异解释为配对策略效应。表S11b使用同一201个实例，涉及AMPlify109个和tsAMP-I92个。

同来源129/201指五个开发来源中至少一个来源的条件错误超过5%；留出来源46/201指单一来源超过5%。两者事件不同。所有201个逐来源规则在同来源验证上的混合错误仍不高于5%，说明总体混合错误达标和每个来源达标是不同要求。

## 本地复算

在有numpy的Python环境中，进入本文件夹后运行 `python rebuild_step1_tables.py`。也可运行 `python rebuild_step1_tables.py 本文件夹绝对路径`。脚本先验证七个输入文件的SHA256，再重建表S11a至S11f和summary.json、analysis_QA.json，不改Word、备份或输入。表S11f来自组划分审计文件，用于评价样本量；原始冻结字节和完整变换均已保留。

本次包属于当前修订的本地补充源数据，没有自动上传GitHub或改动公开v1.0.1。正文参考文献、图4配对差值、家族稳定性及全文复算索引属于后续步骤，本次没有据此扩大修改范围。
