from pathlib import Path
from hashlib import sha256
from zipfile import ZipFile
from collections import Counter
import json,math,csv,re,shutil
from lxml import etree as E
from docx import Document

OUT=Path(Path('tmp/step1_validation_20261101/current_path.txt').read_text(encoding='utf8').strip())
manifest=json.loads((OUT/'input_manifest.json').read_text(encoding='utf8'))
receipt=json.loads((OUT/'word_edit_receipt.json').read_text(encoding='utf8'))
ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main','m':'http://schemas.openxmlformats.org/officeDocument/2006/math'}
def image_hashes(d):
    return [sha256(d.part.related_parts[rid].blob).hexdigest() for p in d.paragraphs for rid in p._p.xpath('.//a:blip/@r:embed')]
report={}
for k,v in manifest['original_documents'].items():
    original=OUT/'backup'/v['name'];staged=OUT/'staged'/v['name']
    assert sha256(original.read_bytes()).hexdigest()==v['sha256']
    assert sha256(staged.read_bytes()).hexdigest()==receipt['staged'][k]['sha256']
    a,b=Document(original),Document(staged)
    assert image_hashes(a)==image_hashes(b)
    assert len(b.tables)==len(a.tables)+(3 if k=='supp' else 0)
    for old,new in zip(a.tables,b.tables):
        assert [[c.text for c in r.cells] for r in old.rows]==[[c.text for c in r.cells] for r in new.rows]
    with ZipFile(original) as za,ZipFile(staged) as zb:
        xa=E.fromstring(za.read('word/document.xml'));xb=E.fromstring(zb.read('word/document.xml'))
        eq1=[E.tostring(x,method='c14n') for x in xa.findall('.//m:oMath',ns)];eq2=[E.tostring(x,method='c14n') for x in xb.findall('.//m:oMath',ns)]
        assert eq1==eq2
        for name in zb.namelist():
            if name.endswith('.xml'):E.fromstring(zb.read(name))
        assert len(xb.findall('.//w:highlight',ns))>len(xa.findall('.//w:highlight',ns))
    originals=[p.text for p in a.paragraphs];revisions=[p.text for p in b.paragraphs]
    changed_old={x['old'] for x in receipt['changes'] if x['old']}
    for p in originals:
        if p and p not in changed_old:assert p in revisions,(k,'Unexpected paragraph loss',p[:90])
    assert not any('\ufffd' in p or 'Error! Reference' in p for p in revisions)
    report[k]={'sha256':sha256(staged.read_bytes()).hexdigest(),'images_unchanged':len(image_hashes(a)),'original_tables_unchanged':len(a.tables),'equations_preserved':len(eq1),'paragraphs':len(b.paragraphs),'table_structures':len(b.tables)}

supp=Document(OUT/'staged'/manifest['original_documents']['supp']['name'])
caps=[int(m[1]) for p in supp.paragraphs if (m:=re.match(r'^Supplementary Table S(\d+)\.',p.text))]
assert caps==list(range(1,12)),caps
all_rows=list(csv.DictReader((OUT/'tables/Table_S11c_absolute_by_model_held_source_phase.tsv').open(encoding='utf8'),delimiter='\t'))
assert len(all_rows)==270
assert sum(int(r['feasible_instances'])==0 for r in all_rows)==117
assert all(int(r['planned_instances'])==20 for r in all_rows)
assert all((int(r['error_pct_valid'])==0 and r['error_pct_median']=='nan') if int(r['feasible_instances'])==0 else int(r['error_pct_valid'])==int(r['feasible_instances']) for r in all_rows)
report['source_resolved']={'combinations':270,'zero_feasibility_combinations':117,'logical_tables':11,'undefined_errors_preserved':True}

# Verify summaries using a separate sorted linear interpolation implementation.
points=list(csv.DictReader((OUT/'inputs/evaluation_points.tsv').open(encoding='utf-8-sig'),delimiter='\t'))
def percentile(a,q):
    a=sorted(a)
    if not a:return math.nan
    x=(len(a)-1)*q;i=int(math.floor(x));j=int(math.ceil(x));return a[i]+(a[j]-a[i])*(x-i)
fields={'error_pct':'conditional_error_balanced','coverage_pct':'coverage_balanced','positive_rejection_pct':'positive_discarded_fraction_balanced','n':'n','positive':'positive','groups':'groups','retained_n':'retained_n'}
summary=json.loads((OUT/'summary.json').read_text(encoding='utf8'))
for row in summary['stratified']:
    rr=[p for p in points if p['phase']==row['phase'] and p['policy']==row['policy'] and p['model']==row['model'] and p['held_source']==row['held_source'] and p['policy_status']=='feasible']
    for name,col in fields.items():
        a=[float(p[col])*(100 if name.endswith('_pct') else 1) for p in rr if math.isfinite(float(p[col]))]
        for suffix,q in [('median',.5),('q25',.25),('q75',.75)]:
            got=percentile(a,q);saved=row[name+'_'+suffix]
            assert (math.isnan(got) and math.isnan(saved)) or abs(got-saved)<1e-10
report['independent_summary_check']='all 270 combination summaries match sorted linear interpolation'

# Build a portable table-only rerun script. It never edits a Word file or its backup.
src=Path('tmp/step1_validation_20261101/analyze.py').read_text(encoding='utf8')
imports=src[:src.index('ROOT=')]
labels=src[src.index("POL=["):src.index('manifest=')]
body=src[src.index('def read(name):'):]
body=body.replace("(OUT/'input_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf8')\n",'')
body=body.replace("Path('tmp/step1_validation_20261101/current_path.txt').write_text(str(OUT),encoding='utf8')\n",'')
head="""OUT=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).resolve().parent
SRC=OUT/'inputs'
manifest=json.loads((OUT/'input_manifest.json').read_text(encoding='utf8'))
for name,item in manifest['files'].items():
    assert sha256((SRC/name).read_bytes()).hexdigest()==item['sha256'],('Input changed',name)
(OUT/'tables').mkdir(exist_ok=True)
"""
extra="""
sample_dicts=[]
for phase,ncol,gcol in [('selection','selection_n','selection_groups'),('same_source_validation','validation_n','validation_groups'),('held_source','held_n','held_groups')]:
    for held in SOURCES:
        a=[r for r in audit if r['held_source']==held]
        nq=np.quantile([int(r[ncol]) for r in a],[.5,.25,.75]);gq=np.quantile([int(r[gcol]) for r in a],[.5,.25,.75])
        sample_dicts.append({'phase':phase,'held_source':held,'partitions':20,'n_median':nq[0],'n_q25':nq[1],'n_q75':nq[2],'groups_median':gq[0],'groups_q25':gq[1],'groups_q75':gq[2]})
write('Table_S11f_evaluation_sample_sizes.tsv',sample_dicts)
"""
(OUT/'rebuild_step1_tables.py').write_text(imports+head+labels+body+extra,encoding='utf8')
shutil.copy2('tmp/step1_validation_20261101/update_words.py',OUT/'word_edit_source.py')
shutil.copy2('tmp/step1_validation_20261101/verify_and_package.py',OUT/'verification_source.py')
(OUT/'structural_QA.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
(OUT/'README_步骤与结果.md').write_text('''# 图5绝对验证结果

本次工作完成三策略在阈值选择、同来源验证及留出来源上的绝对结果汇总。所有输入与已归档超算FORMAL输出逐字节一致。没有重新训练、模型推理、阈值选择或bootstrap。新表S11及本次文字修改已在暂存Word中黄色高亮，核验后将写回原文件。

## 文件

- tables/Table_S11a_absolute_all_available.tsv，9行，三政策及三个阶段，各自全部可用实例。
- tables/Table_S11b_absolute_paired_201.tsv，6行，同一201个配对可行实例。
- tables/Table_S11c_absolute_by_model_held_source_phase.tsv，270行，完整政策、模型、留出来源和阶段组合，含117个零可行组合。
- tables/Table_S11d_paired_201_instance_outcomes.tsv，1206行，201实例乘两政策乘三阶段。
- tables/Table_S11e_individual_evaluation_sources.tsv，19800行，逐实例、阶段和评价来源。保留源表的threshold_negative字段，其含义为历史来源阴性标签，不代表实验测定阴性。
- tables/Table_S11f_evaluation_sample_sizes.tsv，18行，各留出来源与阶段的评价记录和依赖组数。
- inputs目录为本次使用的正式冻结输出；input_manifest.json保留SHA256与正式结果核对信息。
- analysis_QA.json及structural_QA.json为数值和Word保留性检查。

## 统计口径

选择集和同来源验证集含五个开发来源。等初始来源权重下，覆盖率为各来源保留比例的均值。设来源记录数n_s，保留记录k_s，保留错误e_s，阳性P_s，保留阳性p_s，则条件混合错误为Σ(e_s/n_s)/Σ(k_s/n_s)，阳性拒绝为Σ((P_s−p_s)/n_s)/Σ(P_s/n_s)。来源保留后的权重与其覆盖比例成正比。留出来源使用一个来源的普通记录比例。

可用实例中的每个实例各贡献一次，不再平衡不同模型或留出来源的可用实例数量。汇总为中位数和线性插值的25%及75%分位数，表示重复划分敏感性，不是置信区间。单独中位数之差不等于配对差值中位数。三政策全部可用实例并不相同，不能把表S11a之间的直接差异解释为配对策略效应。表S11b使用同一201个实例，涉及AMPlify109个和tsAMP-I92个。

同来源129/201指五个开发来源中至少一个来源的条件错误超过5%；留出来源46/201指单一来源超过5%。两者事件不同。所有201个逐来源规则在同来源验证上的混合错误仍不高于5%，说明总体混合错误达标和每个来源达标是不同要求。

## 本地复算

在有numpy的Python环境中，进入本文件夹后运行 `python rebuild_step1_tables.py`。也可运行 `python rebuild_step1_tables.py 本文件夹绝对路径`。脚本先验证七个输入文件的SHA256，再重建表S11a至S11f和summary.json、analysis_QA.json，不改Word、备份或输入。表S11f来自组划分审计文件，用于评价样本量；原始冻结字节和完整变换均已保留。

本次包属于当前修订的本地补充源数据，没有自动上传GitHub或改动公开v1.0.1。正文参考文献、图4配对差值、家族稳定性及全文复算索引属于后续步骤，本次没有据此扩大修改范围。
''',encoding='utf8')
print(json.dumps(report,ensure_ascii=False),flush=True)
