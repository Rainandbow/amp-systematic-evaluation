from pathlib import Path
from datetime import datetime
from collections import Counter,defaultdict
from hashlib import sha256
import csv,json,math,shutil,sys
import numpy as np

OUT=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).resolve().parent
SRC=OUT/'inputs'
manifest=json.loads((OUT/'input_manifest.json').read_text(encoding='utf8'))
for name,item in manifest['files'].items():
    assert sha256((SRC/name).read_bytes()).hexdigest()==item['sha256'],('Input changed',name)
(OUT/'tables').mkdir(exist_ok=True)
POL=['mixture_original','mixture_source_support','per_source_supported']
PLABEL=dict(zip(POL,['Pooled','Support-matched','Per-source']))
MODELS=['Macrel','AMPlify','ampir','tsAMP_I','HMD_AMP']
MLABEL={'Macrel':'Macrel','AMPlify':'AMPlify','ampir':'ampir','tsAMP_I':'tsAMP-I','HMD_AMP':'HMD-AMP'}
SOURCES=['AMPlify','tsAMP_I','c_AMPs_benchmark_resplit','HMD_AMP','AmPEP_raw_source','ampir_raw_mature90']
SLABEL=dict(zip(SOURCES,['AMPlify','tsAMP-I','c_AMPs','HMD-AMP','AmPEP','ampir']))
PHASES=['selection','same_source_validation','held_source']
PHLABEL=dict(zip(PHASES,['Selection','Same-source validation','Held-source evaluation']))
def read(name):
    with (OUT/'inputs'/name).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f,delimiter='\t'))
def val(x):
    try:return float(x)
    except (ValueError,TypeError):return math.nan
def finite(x):return math.isfinite(val(x))
def write(name,rows):
    fields=list(rows[0]);p=OUT/'tables'/name
    with p.open('w',encoding='utf8',newline='') as f:
        w=csv.DictWriter(f,fields,delimiter='\t',lineterminator='\n');w.writeheader();w.writerows(rows)
    return p
def key(r):return (r['held_source'],int(r['repeat']),r['model'],r['policy'])
rules=read('selected_rules.tsv');points=read('evaluation_points.tsv');details=read('evaluation_by_source.tsv');pairs=read('paired_strategy_differences.tsv');audit=read('group_and_exact_overlap_audit.tsv');ineligible=read('score_ineligible.tsv')
assert len(rules)==1800 and len(points)==5400 and len(details)==19800 and len(ineligible)==360
assert all(r['smoke_only']=='False' for r in rules+points+details+pairs+ineligible)
assert len({key(r) for r in rules})==len(rules)
assert Counter(r['policy'] for r in rules)=={p:600 for p in POL}
assert Counter(r['phase'] for r in points)=={p:1800 for p in PHASES}
assert all(int(r[x])==0 for r in audit for x in ['group_overlap_selection_validation','exact_overlap_selection_validation','group_overlap_development_held','exact_overlap_development_held'])
assert all(r['passed']=='True' for r in read('original_policy_reproduction.tsv'))
rix={key(r):r for r in rules};pix={(key(r),r['phase']):r for r in points};dix=defaultdict(list)
for r in details:dix[key(r),r['phase']].append(r)
feasibility={p:sum(r['policy_status']=='feasible' for r in rules if r['policy']==p) for p in POL}
assert list(feasibility.values())==[458,312,201]
outcomes=Counter(r['outcome_status'] for r in points)
maxdiff=0.;checked=0
metricmap={'coverage_balanced':lambda d:sum(val(r['coverage']) for r in d)/len(d),
 'conditional_error_balanced':lambda d:sum(val(r['retained_errors'])/int(r['n']) for r in d)/sum(val(r['retained_n'])/int(r['n']) for r in d),
 'positive_discarded_fraction_balanced':lambda d:sum(val(r['positive_discarded'])/int(r['n']) for r in d)/sum(int(r['positive'])/int(r['n']) for r in d)}
for r in points:
    k=key(r);d=dix[k,r['phase']]
    assert len(d)==(1 if r['phase']=='held_source' else 5)
    assert sum(int(s['n']) for s in d)==int(r['n'])
    assert sum(int(s['positive']) for s in d)==int(r['positive'])
    assert r['policy_status']==rix[k]['policy_status']
    assert all(s['policy_status']==r['policy_status'] for s in d)
    if r['policy_status']=='feasible':
        assert all(int(s['n'])>0 for s in d)
        assert sum(int(s['retained_n']) for s in d)==int(r['retained_n'])
        for met,fn in metricmap.items():
            got=fn(d);expect=val(r[met]);delta=abs(got-expect);maxdiff=max(maxdiff,delta)
            assert delta<1e-12,(met,got,expect)
            assert 0<=expect<=1
        f=[val(s['conditional_error']) for s in d if finite(s['conditional_error'])]
        assert abs(max(f)-val(r['worst_source_error']))<1e-12
        if r['policy']=='per_source_supported' and r['phase']=='selection':assert max(f)<=.05+1e-12
        checked+=1
    else:
        assert r['outcome_status']=='policy_unavailable' and not finite(r['conditional_error_balanced'])

def quantile_fields(rows,name,fn,scale=1):
    a=np.array([fn(r) for r in rows],dtype=float)*scale;a=a[np.isfinite(a)]
    return {name+'_valid':len(a),**{name+'_'+label:float(np.quantile(a,q,method='linear')) if len(a) else math.nan for label,q in [('median',.5),('q25',.25),('q75',.75),('min',0),('max',1)]}}
MET={'error_pct':lambda r:val(r['conditional_error_balanced']),'coverage_pct':lambda r:val(r['coverage_balanced']),'positive_rejection_pct':lambda r:val(r['positive_discarded_fraction_balanced'])}
def summary(rr,meta,planned):
    rr=list(rr);available=[r for r in rr if r['policy_status']=='feasible'];estimable=[r for r in available if r['outcome_status']=='estimable']
    result={**meta,'planned_instances':planned,'feasible_instances':len(available),'unavailable_instances':len(rr)-len(available),'estimable_instances':len(estimable),'zero_retention_instances':sum(r['outcome_status']=='zero_retained_error_undefined' for r in available)}
    for name,fn in MET.items():result.update(quantile_fields(available,name,fn,100))
    for name in ['n','positive','groups','retained_n']:
        result.update(quantile_fields(available,name,lambda r,name=name:val(r[name])))
    result['mixture_error_gt5_count']=sum(val(r['conditional_error_balanced'])>.05+1e-12 for r in available if finite(r['conditional_error_balanced']))
    result['mixture_error_gt5_denominator']=sum(finite(r['conditional_error_balanced']) for r in available)
    result['any_evaluated_source_error_gt5_count']=sum(val(r['worst_source_error'])>.05+1e-12 for r in available if finite(r['worst_source_error']))
    result['any_evaluated_source_error_gt5_denominator']=sum(finite(r['worst_source_error']) for r in available)
    result['evaluation_sources_per_instance']=5 if meta['phase']!='held_source' else 1
    result['summary_type']='median_and_IQR_across_repeated_partitions_NOT_CI'
    return result
overall=[];stratified=[]
for phase in PHASES:
    for p in POL:
        rr=[r for r in points if r['phase']==phase and r['policy']==p]
        overall.append(summary(rr,{'phase':phase,'phase_label':PHLABEL[phase],'policy':p,'policy_label':PLABEL[p]},600))
    for m in MODELS:
        for held in SOURCES:
            for p in POL:
                rr=[pix[((held,i,m,p),phase)] for i in range(1,21)]
                stratified.append(summary(rr,{'phase':phase,'phase_label':PHLABEL[phase],'model':m,'model_label':MLABEL[m],'held_source':held,'held_source_label':SLABEL[held],'policy':p,'policy_label':PLABEL[p]},20))
paired_keys={(r['held_source'],int(r['repeat']),r['model']) for r in rules if r['policy']=='per_source_supported' and r['policy_status']=='feasible'}
assert len(paired_keys)==201
assert all(rix[(h,i,m,'mixture_source_support')]['policy_status']=='feasible' for h,i,m in paired_keys)
paired_abs=[];paired_detail=[]
for phase in PHASES:
    for p in ['mixture_source_support','per_source_supported']:
        rr=[pix[((h,i,m,p),phase)] for h,i,m in sorted(paired_keys)]
        paired_abs.append(summary(rr,{'phase':phase,'phase_label':PHLABEL[phase],'policy':p,'policy_label':PLABEL[p],'subset':'same_201_jointly_feasible_instances'},201))
        paired_detail.extend({**r,'paired_subset':'same_201_jointly_feasible_instances'} for r in rr)
q={ (r['phase'],r['policy']):r for r in paired_abs}
assert q['same_source_validation','per_source_supported']['any_evaluated_source_error_gt5_count']==129
assert q['held_source','per_source_supported']['mixture_error_gt5_count']==46
assert q['held_source','mixture_source_support']['mixture_error_gt5_count']==85
paired_medians={}
for met in ['conditional_error_balanced','coverage_balanced','positive_discarded_fraction_balanced']:
    a=[r for r in pairs if r['phase']=='held_source' and r['policy_a']=='per_source_supported' and r['policy_b']=='mixture_source_support' and r['metric']==met and r['status']=='paired_feasible']
    assert len(a)==201
    got=np.median([float(r['difference'])*100 for r in a]);paired_medians[met]=got
    expected={'conditional_error_balanced':-2.90,'coverage_balanced':-25.22,'positive_discarded_fraction_balanced':28.28}[met]
    assert abs(round(got,2)-expected)<1e-9
    for r in a:
        h,i,m=r['held_source'],int(r['repeat']),r['model']
        expect=val(pix[((h,i,m,'per_source_supported'),'held_source')][met])-val(pix[((h,i,m,'mixture_source_support'),'held_source')][met])
        assert abs(expect-float(r['difference']))<1e-12

write('Table_S11a_absolute_all_available.tsv',overall)
write('Table_S11b_absolute_paired_201.tsv',paired_abs)
write('Table_S11c_absolute_by_model_held_source_phase.tsv',stratified)
write('Table_S11d_paired_201_instance_outcomes.tsv',paired_detail)
# Preserve individual evaluated-source outcomes with readable model/source labels.
source_output=[]
for r in details:
    source_output.append({**r,'model_label':MLABEL[r['model']],'held_source_label':SLABEL[r['held_source']],'source_label':SLABEL[r['source']],'policy_label':PLABEL[r['policy']],'phase_label':PHLABEL[r['phase']]})
write('Table_S11e_individual_evaluation_sources.tsv',source_output)
qa={'formal_inputs_match_archived_server_output':True,'source_phase_rows_checked':len(details),'phase_rows':len(points),'selected_rules':len(rules),'ineligible_states':len(ineligible),'all_smoke_only_false':True,'all_exact_and_group_overlap_checks_zero':True,'recomputed_estimable_phase_metrics':checked,'max_source_to_phase_metric_difference':maxdiff,'feasible_counts':feasibility,'outcome_status':dict(outcomes),'paired_instances':201,'paired_held_median_changes_pp':paired_medians,'same_source_any_of_five_violation_129':True,'held_one_source_violations_85_and_46':True,'new_model_inference':False,'new_bootstrap':False,'quantile_method':'numpy quantile linear','numpy_version':np.__version__}
(OUT/'analysis_QA.json').write_text(json.dumps(qa,ensure_ascii=False,indent=2),encoding='utf8')
(OUT/'summary.json').write_text(json.dumps({'overall':overall,'paired_201':paired_abs,'stratified':stratified,'labels':{'policies':PLABEL,'models':MLABEL,'sources':SLABEL,'phases':PHLABEL}},ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps({'output':str(OUT),'qa':qa,'paired_summary':paired_abs},ensure_ascii=False),flush=True)

sample_dicts=[]
for phase,ncol,gcol in [('selection','selection_n','selection_groups'),('same_source_validation','validation_n','validation_groups'),('held_source','held_n','held_groups')]:
    for held in SOURCES:
        a=[r for r in audit if r['held_source']==held]
        nq=np.quantile([int(r[ncol]) for r in a],[.5,.25,.75]);gq=np.quantile([int(r[gcol]) for r in a],[.5,.25,.75])
        sample_dicts.append({'phase':phase,'held_source':held,'partitions':20,'n_median':nq[0],'n_q25':nq[1],'n_q75':nq[2],'groups_median':gq[0],'groups_q25':gq[1],'groups_q75':gq[2]})
write('Table_S11f_evaluation_sample_sizes.tsv',sample_dicts)
