# 第二步：六模型相对“最短序列优先”的配对命中差

本次已在同名原正文与补充材料中更新并标黄。原文件修改前的副本在 backup/。主图仍为六张；仅更新图4，新增补充图S26和补充表S12。第一步的图5绝对验证结果与表S11保留。

## 主要结果与解释

同一100条ApexGO template-based候选、E. coli ATCC11775初始MIC≤64 μM、20条预算：最短序列优先命中12个阳性。

| 模型 | 模型命中数 | 模型−最短优先 | 配对95%区间 |
|---|---:|---:|---:|
| Macrel | 3.50 | −8.50 | [−14.80, 0.59] |
| AMPlify | 7.00 | −5.00 | [−10.00, 2.83] |
| ampir | 8.00 | −4.00 | [−13.00, 9.46] |
| tsAMP-I | 10.00 | −2.00 | [−6.00, 3.71] |
| HMD-AMP | 11.00 | −1.00 | [−6.00, 6.43] |
| c_AMPs* | 8.00 | −4.00 | [−6.00, 3.00] |

正差值表示模型找回更多阳性，负差值表示更少。小数来自边界同分候选的均匀分数权重，不代表测了半条肽。c_AMPs*仅在排序中使用已有最小分支分数扩展，不替换原生严格AND分类。

六个点估计均为负，但六个配对区间均含零，尚不能确立模型的稳定增益，也不能据此证明等效或稳定劣于最短优先。区间仍允许实际的增益和损失。

同一队列“任一受测菌株”活动任务：六模型均命中20个阳性，最短优先命中16个，配对差均为+4，六个区间也均含零。随机选择期望17.2个；“相对随机的2.8个”与“相对最短优先的4个”为不同参照。

## 完整比较与区间

四队列×两任务×六模型=48项对照全部保留，见 tables/Table_S12_all_48_paired_hit_differences.tsv。18项有可报告区间，6项因全阳性造成退化差值分布而省略，24项因HydrAMP仅有四个或两个依赖块而不满足五块规则。省略区间不是确定性结果。

区间直接摘录既有正式10,000次配对块bootstrap结果：每次共享同一批抽样块与记录重数，以重采样后的记录数n*重新设定K=ceil(0.2n*)，各方法重新排序、分配同分权重，再取“模型命中−最短优先命中”。95%限值来自这些配对差值分位数，不是两个边际区间端点相减。区间为探索性、逐项区间，未多重校正。

最短序列优先是在此次修订中选作具名展示对照，选择发生于较早结果已知之后。六种原有未拟合基线及完整1,440项比较仍保留，不把该对照重新描述为事先指定或唯一基线。

## 文件

- figures/Figure_4_updated_paired_gain.*：更新主图4，b面板为六模型配对命中差。
- figures/Figure_S26_all_paired_hit_differences.*：八面板展示全部48项差值。
- tables/：完整S12表、图4各面板源表、96项独立点估计重建核查。
- inputs/：经SHA256核对、与正式服务器存档一致的统计输出及冻结成员/分数。
- source/：既有正式统计实现、协议与本次Word编辑记录。
- qa/：输入、数值、图件、Word结构和分页核查。
- backup/：两份修改前原稿。
- word_export/：对应本次Word的审阅PDF。

## 重建步骤（本地即可）

在此目录运行：

```powershell
python extract_paired.py
python -m pip install -r requirements_figures.txt
python plot_paired.py
python tools/validate_figure.py plot_paired.py --backend python --json
python tools/audit_pdf_text.py figures/Figure_4_updated_paired_gain.pdf --min-pt 6 --json
python tools/audit_figure_collisions.py figures/Figure_4_updated_paired_gain.pdf
python tools/audit_pdf_text.py figures/Figure_S26_all_paired_hit_differences.pdf --min-pt 6 --json
python tools/audit_figure_collisions.py figures/Figure_S26_all_paired_hit_differences.pdf
```

extract_paired.py仅用Python标准库，不重新bootstrap；它独立重算96个点估计，并重建五张源表。plot_paired.py从保存的配对区间和点估计出图，不运行模型或重新抽样。软件安装可在独立环境中完成。python_deps/仅为此次任务的本地工具依赖缓存，不是数据或正式分析结果，也不包含在精简复现包内。

## 本次核查范围

重建的五张表逐字节一致；图4及S26通过源代码、字体、面板对齐与碰撞核查。正文24页、补充材料49页完成逐页版面核查。原有表格、SI前25张图和八个原生公式保留；主图仅第4张被替换。GitHub/Zenodo版本未在本次操作中变更；上述新增展示应随下一次代码/数据发布同步。
