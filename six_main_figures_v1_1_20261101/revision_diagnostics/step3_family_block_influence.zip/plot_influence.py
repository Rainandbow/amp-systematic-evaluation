"""Frozen-output influence figure; deletion ranges are descriptive, not CIs."""
from pathlib import Path
import csv,sys,math
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

OUT=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).resolve().parent
sys.path.insert(0,str(OUT/'tools'))
from audit_panel_alignment import require_matplotlib_panel_alignment

plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Arial','DejaVu Sans'],'font.size':7,'axes.labelsize':7,'xtick.labelsize':6.5,'ytick.labelsize':7,'pdf.fonttype':42,'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False,'axes.linewidth':.65,'legend.frameon':False})
TEAL='#257E91';ORANGE='#B8773B';GRAY='#E7ECEF';DARK='#23282D'
MODELS=['Macrel','AMPlify','ampir','tsAMP_I','HMD_AMP','c_AMPs']
LABELS={'tsAMP_I':'tsAMP-I','HMD_AMP':'HMD-AMP','c_AMPs':'c_AMPs*'}
PRIMARY='ApexGO_template_based';REF='source_reference_Ecoli'
def read(name):
 with (OUT/'tables'/name).open(encoding='utf-8-sig') as f:return list(csv.DictReader(f,delimiter='\t'))
contrib=[r for r in read('full_selection_block_contributions.tsv') if r['cohort']==PRIMARY and r['task']==REF and r['method']=='length_low']
case=[r for r in read('Fig_S27_primary_deletion_contrasts.tsv') if r['task']==REF]
contrib=sorted(contrib,key=lambda r:r['family'])
assert len(contrib)==10 and abs(sum(float(r['selected_hits']) for r in contrib)-12)<1e-10

fig,axs=plt.subplots(2,2,figsize=(183/25.4,178/25.4))
fig.subplots_adjust(left=.215,right=.985,bottom=.09,top=.89,wspace=.81,hspace=.64)

def title(ax,letter,label):
 ax.text(0,1.065,letter,transform=ax.transAxes,fontsize=8,fontweight='bold',ha='left',va='bottom',gid='panel-label')
 ax.text(.075,1.065,label,transform=ax.transAxes,fontsize=7.5,ha='left',va='bottom')

ax=axs[0,0]
hit=np.array([float(r['selected_hits']) for r in contrib])
selected=np.array([float(r['selected_weight']) for r in contrib]);size=np.array([int(r['n']) for r in contrib])
ax.barh(range(10),hit,color=TEAL,height=.58,label='Selected positive')
ax.barh(range(10),selected-hit,left=hit,color=ORANGE,height=.58,label='Selected threshold-negative')
ax.barh(range(10),size-selected,left=selected,color=GRAY,height=.58,label='Unselected')
ax.set_yticks(range(10),[r['family'] for r in contrib]);ax.set_ylim(9.7,-.7)
ax.set_xlim(0,10.25);ax.set_xticks([0,5,10]);ax.set_xlabel('Candidate weight')
ax.tick_params(axis='y',length=0,pad=4);ax.spines['left'].set_visible(False)
title(ax,'a','Shortest-first selection')
handles,labels=ax.get_legend_handles_labels()
fig.legend(handles,labels,loc='upper left',bbox_to_anchor=(.21,.985),ncol=2,fontsize=6.5,handlelength=1.2,columnspacing=1.2,labelspacing=.45)

def plot_cases(ax,order,key,lims,ticks,letter,label,xlabel):
 for i,model in enumerate(MODELS):
  rr=sorted([r for r in case if r['model']==model and int(r['order'])==order],key=lambda r:r['deletion_case'])
  vals=np.array([float(r[key+'_difference']) for r in rr])
  full=float(rr[0]['full_hit_difference' if key=='positive_hits' else 'full_macro_AUROC_difference'])
  assert len(vals)==(10 if order==1 else 45) and np.isfinite(vals).all()
  ax.hlines(i,vals.min(),vals.max(),color=TEAL,lw=.85,zorder=1)
  y=i+np.linspace(-.17,.17,len(vals))
  ax.scatter(vals,y,s=6,color=TEAL,alpha=.65,edgecolors='none',zorder=2)
  ax.plot(full,i,'D',ms=3.8,mfc=DARK,mec='white',mew=.35,zorder=3)
 ax.axvline(0,color='#9FA6AC',ls=(0,(3,2)),lw=.7,zorder=0)
 ax.set_yticks(range(6),[LABELS.get(m,m) for m in MODELS]);ax.set_ylim(5.55,-.55)
 ax.tick_params(axis='y',length=0,pad=4);ax.spines['left'].set_visible(False)
 ax.set_xlim(*lims);ax.set_xticks(ticks);ax.set_xlabel(xlabel)
 title(ax,letter,label)

plot_cases(axs[0,1],1,'positive_hits',(-10.5,2.5),[-10,-5,0],'b','One block removed','Hits relative to shortest-first')
plot_cases(axs[1,0],2,'positive_hits',(-10.5,7),[-10,-5,0,5],'c','Two blocks removed','Hits relative to shortest-first')
plot_cases(axs[1,1],1,'macro_within_family_AUROC',(-.065,.41),[0,.1,.2,.3,.4],'d','Within-family ranking','AUROC relative to shortest-first')
fig.canvas.draw()
stem=OUT/'figures/Figure_S27_family_block_influence'
require_matplotlib_panel_alignment(fig,axes=list(axs.flat),panel_ids=list('abcd'),json_out=str(stem)+'.alignment.json',overlay_svg=str(stem)+'.alignment.svg',tolerance_pt=1.5,gutter_tolerance_pt=1.5,strict=True)
fig.savefig(str(stem)+'.pdf')
fig.savefig(str(stem)+'.svg')
fig.savefig(str(stem)+'.png',dpi=600)
fig.savefig(str(stem)+'.tiff',dpi=600)
plt.close(fig)
print('PLOT COMPLETE',stem)
