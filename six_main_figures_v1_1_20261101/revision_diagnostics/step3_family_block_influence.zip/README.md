# 第三步：检查少数家族或依赖块的影响

已完成本地计算，并将结果同步到同名正文及补充材料，改动处黄色高亮。backup/保存修改前版本。主图仍为六张；新增补充图S27、表S13和表S14。

## 主要发现

1. 历史六来源：共有1,296、12,493、5,916、1,108、5,168和583个全局依赖组。逐组删除后，来源总体MCC的最大绝对变化为0.0062662，按正文精度报告0.0063。这支持来源总体点估计对单组删除较稳定；不等于证明所有区间准确或所有指标都不受依赖影响。
2. 稀疏长度层：18条记录的AMPlify 100–126层中，AMPlify的MCC由0.8619变为0.8345–1.0000，最大变化0.1381。tsAMP-I 100–126层只有一个来源阳性，删除它所在组后MCC未定义。空层、单类别层和删除后的未定义值均保留。
3. 主ApexGO队列：100条候选对应10个家族/块，每块10条、占10%。不存在一个特别大的块，但分类构成不同。参考菌株任务中，最短优先的12个阳性命中全部来自两个家族：Arctoterin-1贡献4个，Mammuthusin-3贡献8个。
4. 删除Mammuthusin-3后，ampir和HMD-AMP相对最短优先的命中差分别变为+1.80和+0.80，方向与原完整队列相反。固定原20条容量的敏感性分析也出现相同模型的单家族方向反转，说明不只由预算从20变为18引起。
5. 在所有单块删除中，Macrel、AMPlify、tsAMP-I和c_AMPs*的参考任务命中差保持负值；在全部45个双块删除组合中，只有Macrel始终为负。不能把结果概括为“六模型稳定劣于最短优先”。
6. 家族内比较：参考任务的均值AUROC有九个信息家族/块、90条候选（33阳性、57阈值阴性），任一受测菌株任务只有四个信息家族/块、40条（26阳性、14阈值阴性）。五个模型的参考任务家族内AUROC点差在逐一家族删除后仍为正；这是不同于候选池预算命中的描述性估计，不构成新的显著性结论或新家族泛化证据。

## 如何理解删除检查

所有四个新增实验cohort的家族与依赖块均一一对应，已逐条核对成员集合。因此，对应的家族删除和块删除是同一项扰动，不作为两份独立证据。

每个cohort逐一删除全部块；主100条队列还检查全部45个双块组合。保留分数、标签、模型与分组ID不变，删除后重新排序和分配边界同分权重。主政策K=ceil(0.2n_remaining)：删除一个块后n=90、K=18，删除两个后n=80、K=16。另保留原容量K=20作敏感性分析。

图中范围是所有删除结果的最小值和最大值，不是95%置信区间。删除病例共享候选，不是独立重复。完整队列和上一轮表S12中的配对bootstrap区间保留不变；本次没有重跑模型、bootstrap或聚类，也没有从主分析永久去掉影响较大的家族。

## 文件导航

- figures/Figure_S27_family_block_influence.*：家族选择贡献、逐块/双块预算命中差、家族内AUROC差。
- tables/Table_S13_historical_group_composition.tsv：六来源×全部/四长度层×全局/局部组，共60行，含组数、大小与类别构成。
- tables/Table_S13_experimental_group_composition.tsv：四cohort×两任务的块及信息家族分母。
- tables/Table_S13_experimental_family_block_roster.tsv：逐家族/块、n/P/N及贡献权重。
- tables/full_selection_block_contributions.tsv：全部方法在原固定选择下的块级命中贡献。
- tables/Table_S14_named_comparator_deletion_summary.tsv：具名最短优先对照的全部删除范围、方向计数及固定容量敏感性。
- tables/all_model_minus_six_controls_deletion_contrasts.tsv.gz：全部六种对照，11,664行配对删除结果。
- tables/deletion_sets_and_members.tsv：每个删除集合及剩余成员ID。
- tables/all_deletion_method_points.tsv：3,888行删除后方法点估计。
- tables/historical_single_block_deletion_summary.tsv：180个模型×来源×分层组合。
- tables/historical_single_block_deletions.tsv.gz：完整逐历史组删除值，含未定义状态。
- inputs/：冻结输入；input_manifest.json含SHA256与原始来源记录。
- protocol_step3.json：本次诊断的范围、预算、端点、保留规则与探索性时间说明。
- qa/：重建一致性、独立数值检查、Word结构/版面与图件检查记录。

## 本地复算

在解压目录中运行：

```powershell
python analyze_influence.py
python verify_influence.py
python -m pip install -r requirements_figures.txt
python plot_influence.py
python tools/validate_figure.py plot_influence.py --backend python --json
python tools/audit_pdf_text.py figures/Figure_S27_family_block_influence.pdf --min-pt 6 --json
python tools/audit_figure_collisions.py figures/Figure_S27_family_block_influence.pdf
```

分析和独立验证脚本仅使用Python标准库；绘图依赖可安装在单独环境中。冻结输入已经包含，不需要超算、模型权重或网络下载。压缩包内路径全部使用ASCII，避免此前README中文文件名解压乱码的问题。

本次完整重建14个源表逐字节一致，包括时间戳固定的gzip输出。独立核查用边界分数法和精确分数权重复核全部3,888个命中数，用逐正负对枚举复核相同3,888组的总体及家族内AUROC，并对150个可估计历史组合的最大影响删除直接过滤原记录复算。原有六张主图、前26张补充图、原表格与八个Word原生公式保留。

本地第三步输出与公开v1.0.1归档分开记录；尚未由本次操作上传GitHub/Zenodo。结论限定于冻结候选池、端点和分组，未将删除范围称为置信区间。


## Publication input update for v1.1.0
Historical raw sequence letters are omitted in this publication package. The historical_members.tsv.gz input is the public v1.0.1 SHA256-based table. Its labels, lengths, memberships, groups and predictions match every corresponding original cell and row. All 14 scientific result tables were rebuilt and checked against the existing archived results after this change. This update does not change the reported scientific results.
