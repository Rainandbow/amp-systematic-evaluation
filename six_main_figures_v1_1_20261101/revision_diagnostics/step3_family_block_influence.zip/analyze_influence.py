"""Deterministic family/block deletion diagnostics from frozen AMP outputs."""
from pathlib import Path
from collections import defaultdict,Counter
from hashlib import sha256
from itertools import combinations
import csv,json,gzip,math,sys,io

OUT=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).resolve().parent
MODELS=['Macrel','AMPlify','ampir','tsAMP_I','HMD_AMP','c_AMPs']
BASELINES=['length_high','length_low','KR_minus_DE_high','KR_minus_DE_low','mean_Kyte_Doolittle_high','mean_Kyte_Doolittle_low']
METHODS=MODELS+BASELINES
COHORTS=['ApexGO_template_based','ApexGO_template_free','HydrAMP_auxiliary_preselected','HydrAMP_no_auxiliary_preselection']
TASKS=['any_eligible_measured_strain','source_reference_Ecoli']
PRIMARY=COHORTS[0];NAN=float('nan');EPS=1e-10

def read(name):
 p=OUT/'inputs'/name
 op=gzip.open if name.endswith('.gz') else open
 with op(p,'rt',encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f,delimiter='\t'))

def write(name,rows):
 assert rows,name
 path=OUT/'tables'/name
 stream=io.TextIOWrapper(gzip.GzipFile(filename=path,mode='wb',mtime=0),encoding='utf8',newline='') if name.endswith('.gz') else path.open('w',encoding='utf8',newline='')
 with stream as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]),delimiter='\t',lineterminator='\n');w.writeheader();w.writerows(rows)

def ratio(a,b):return a/b if b else NAN
def finite(x):return math.isfinite(x)
def sign(x):return 1 if x>EPS else (-1 if x<-EPS else 0)
def q(values,p):
 a=sorted(values)
 if not a:return NAN
 i=(len(a)-1)*p;j=int(i);return a[j]+(a[min(j+1,len(a)-1)]-a[j])*(i-j)

def select(scores,K):
 assert 0<=K<=len(scores)
 w=[0.]*len(scores);left=float(K);tiers=defaultdict(list)
 for i,s in enumerate(scores):tiers[s].append(i)
 for s in sorted(tiers,reverse=True):
  ix=tiers[s];weight=min(1.,left/len(ix))
  if weight<=0:break
  for i in ix:w[i]=weight
  left-=weight*len(ix)
 assert abs(sum(w)-K)<EPS
 return w

def auc(labels,scores):
 p=sum(labels);n=len(labels)-p
 if p==0 or n==0:return NAN
 tiers=defaultdict(lambda:[0,0])
 for y,s in zip(labels,scores):tiers[s][y]+=1
 negbelow=0.;wins=0.
 for s in sorted(tiers):
  neg,pos=tiers[s];wins+=pos*(negbelow+.5*neg);negbelow+=neg
 return wins/(p*n)

def metrics(rows,method,K):
 y=[r['y'] for r in rows];s=[r['scores'][method] for r in rows]
 weights=select(s,K);hits=sum(w*t for w,t in zip(weights,y));P=sum(y);n=len(rows)
 fam=defaultdict(list)
 for r in rows:fam[r['family']].append(r)
 informative=[rr for rr in fam.values() if 0<sum(r['y'] for r in rr)<len(rr)]
 fvals=[auc([r['y'] for r in rr],[r['scores'][method] for r in rr]) for rr in informative]
 info=[r for rr in informative for r in rr]
 return {'positive_hits':hits,'precision':ratio(hits,K),'recovery':ratio(hits,P),'excess_hits_vs_random':hits-K*P/n,'pooled_AUROC':auc(y,s),'macro_within_family_AUROC':sum(fvals)/len(fvals) if fvals else NAN,'informative_families':len(fvals),'informative_blocks':len({r['block'] for r in info}),'informative_n':len(info),'informative_positive':sum(r['y'] for r in info),'informative_negative':len(info)-sum(r['y'] for r in info)},weights

def near(a,b):return (not finite(a) and not finite(b)) or math.isclose(a,b,abs_tol=1e-10,rel_tol=1e-10)

manifest=json.loads((OUT/'input_manifest.json').read_text(encoding='utf8'))
for name,d in manifest['inputs'].items():assert sha256((OUT/'inputs'/name).read_bytes()).hexdigest()==d['sha256'],name
members=read('endpoint_membership.tsv');desc=read('descriptor_values.tsv');scores=read('scores151.tsv')
oldpoints=read('baseline_and_model_points.tsv');oldfamilies=read('within_family_details.tsv')
di={r['sequence_id']:r for r in desc};si={(r['sequence_id'],r['model']):r for r in scores}
oi={(r['cohort'],r['task'],r['method']):r for r in oldpoints}
fi={(r['cohort'],r['task'],r['method'],r['family']):r for r in oldfamilies}
assert len(di)==151 and len(si)==906 and len(oi)==96 and len(fi)==864

composition=[];roster=[];original=[];contributions=[];deletions=[];contrasts=[];audit=[];deletion_sets=[]
scorecache={}
for sid,d in di.items():
 scorecache[sid]={m:float(si[sid,m]['score']) for m in MODELS}
 scorecache[sid].update({b:float(d[b]) for b in BASELINES})

for cohort in COHORTS:
 for task in TASKS:
  mm=[r for r in members if r['cohort']==cohort and r['task']==task]
  rows=[dict(record_id=r['record_id'],sequence_id=r['sequence_id'],family=r['family'],block=r['block'],y=int(r['label']),scores=scorecache[r['sequence_id']]) for r in mm]
  n=len(rows);P=sum(r['y'] for r in rows);K=math.ceil(.2*n)
  blocks=sorted({r['block'] for r in rows});fams=sorted({r['family'] for r in rows})
  fmap={f:{r['block'] for r in rows if r['family']==f} for f in fams}
  bmap={b:{r['family'] for r in rows if r['block']==b} for b in blocks}
  assert all(len(s)==1 for s in fmap.values()) and all(len(s)==1 for s in bmap.values())
  # The frozen partitions coincide; a family deletion is the same case as its block deletion.
  for b in blocks:
   f=next(iter(bmap[b]))
   assert {r['record_id'] for r in rows if r['family']==f}=={r['record_id'] for r in rows if r['block']==b}
  for idx,b in enumerate(sorted(blocks,key=lambda b:next(iter(bmap[b]))),1):
   rr=[r for r in rows if r['block']==b];p=sum(r['y'] for r in rr);f=next(iter(bmap[b]))
   roster.append(dict(cohort=cohort,task=task,display_block=f'B{idx:02}',block=b,family=f,n=len(rr),positive=p,negative=len(rr)-p,cohort_n=n,cohort_positive=P,record_share=len(rr)/n,positive_share=ratio(p,P),negative_share=ratio(len(rr)-p,n-P),both_classes=0<p<len(rr),mean_family_AUROC_weight=ratio(1,sum(0<sum(t['y'] for t in rows if t['family']==ff)<sum(t['family']==ff for t in rows) for ff in fams)) if 0<p<len(rr) else 0.))
  sizes=[sum(r['block']==b for r in rows) for b in blocks]
  info=[]
  for f in fams:
   family_rows=[r for r in rows if r['family']==f]
   if 0<sum(r['y'] for r in family_rows)<len(family_rows):info.append(family_rows)
  ir=[r for rr in info for r in rr]
  composition.append(dict(cohort=cohort,task=task,n=n,positive=P,negative=n-P,families=len(fams),blocks=len(blocks),family_block_one_to_one=True,min_block=min(sizes),median_block=q(sizes,.5),max_block=max(sizes),largest_record_share=max(sizes)/n,positive_blocks=sum(any(r['y']==1 for r in rows if r['block']==b) for b in blocks),negative_blocks=sum(any(r['y']==0 for r in rows if r['block']==b) for b in blocks),mixed_blocks=len(info),informative_families=len(info),informative_blocks=len(info),informative_n=len(ir),informative_positive=sum(r['y'] for r in ir),informative_negative=sum(1-r['y'] for r in ir),primary_budget=K,threshold=mm[0]['threshold'],unit=mm[0]['unit'],reference_strain=mm[0]['reference_strain']))
  full={}
  for method in METHODS:
   met,w=metrics(rows,method,K);full[method]=met
   saved=oi[cohort,task,method]
   for key in ['positive_hits','precision','recovery','excess_hits_vs_random','pooled_AUROC','macro_within_family_AUROC']:
    assert near(met[key],float(saved[key])),(cohort,task,method,key,met[key],saved[key])
   original.append(dict(cohort=cohort,task=task,method=method,n=n,positive=P,negative=n-P,blocks=len(blocks),K=K,**met))
   for b in blocks:
    ix=[i for i,r in enumerate(rows) if r['block']==b]
    fam=next(iter(bmap[b]));yy=[rows[i]['y'] for i in ix];ss=[rows[i]['scores'][method] for i in ix]
    assert near(auc(yy,ss),float(fi[cohort,task,method,fam]['family_AUROC']))
    h=sum(w[i]*rows[i]['y'] for i in ix)
    contributions.append(dict(cohort=cohort,task=task,method=method,block=b,family=fam,n=len(ix),positive=sum(yy),selected_weight=sum(w[i] for i in ix),selected_hits=h,full_hits=met['positive_hits'],hit_share=ratio(h,met['positive_hits']),family_AUROC=auc(yy,ss)))
  sets=[(b,) for b in blocks]
  if cohort==PRIMARY:sets+=list(combinations(blocks,2))
  for bb in sets:
   kept=[r for r in rows if r['block'] not in bb];removed=[r for r in rows if r['block'] in bb]
   nn=len(kept);pp=sum(r['y'] for r in kept);case='|'.join(sorted(next(iter(bmap[b])) for b in bb))
   deletion_sets.append(dict(cohort=cohort,task=task,deletion_case=case,deleted_blocks='|'.join(bb),deleted_families=case,order=len(bb),removed_n=len(removed),remaining_n=nn,remaining_positive=pp,remaining_negative=nn-pp,remaining_blocks=len(blocks)-len(bb),removed_records='|'.join(r['record_id'] for r in removed),remaining_records='|'.join(r['record_id'] for r in kept)))
   for policy,kk in [('fraction_20pct',math.ceil(.2*nn)),('fixed_original_capacity',K)]:
    assert 0<kk<=nn
    values={}
    for method in METHODS:
     met,w=metrics(kept,method,kk);values[method]=met
     deletions.append(dict(cohort=cohort,task=task,deletion_case=case,deleted_blocks='|'.join(bb),order=len(bb),budget_policy=policy,method=method,n=nn,positive=pp,negative=nn-pp,blocks=len(blocks)-len(bb),K=kk,**met))
    for model in MODELS:
     for baseline in BASELINES:
      d={key:values[model][key]-values[baseline][key] for key in ['positive_hits','precision','recovery','excess_hits_vs_random','pooled_AUROC','macro_within_family_AUROC']}
      contrasts.append(dict(cohort=cohort,task=task,deletion_case=case,deleted_blocks='|'.join(bb),order=len(bb),budget_policy=policy,model=model,baseline=baseline,n=nn,positive=pp,negative=nn-pp,blocks=len(blocks)-len(bb),K=kk,**{key+'_difference':v for key,v in d.items()},full_hit_difference=full[model]['positive_hits']-full[baseline]['positive_hits'],full_macro_AUROC_difference=full[model]['macro_within_family_AUROC']-full[baseline]['macro_within_family_AUROC'],informative_families=values[model]['informative_families'],informative_n=values[model]['informative_n']))
  audit.append(dict(cohort=cohort,task=task,point_methods_verified=len(METHODS),whole_family_deletion_equals_block_deletion=True,single_cases=len(blocks),two_block_cases=math.comb(len(blocks),2) if cohort==PRIMARY else 0))

write('Table_S13_experimental_group_composition.tsv',composition)
write('Table_S13_experimental_family_block_roster.tsv',roster)
write('full_data_points_reconstructed.tsv',original)
write('full_selection_block_contributions.tsv',contributions)
write('deletion_sets_and_members.tsv',deletion_sets)
write('all_deletion_method_points.tsv',deletions)
write('all_model_minus_six_controls_deletion_contrasts.tsv.gz',contrasts)

# Direct summaries of the named comparator; no baseline selection from these results.
summaries=[]
for cohort in COHORTS:
 for task in TASKS:
  for model in MODELS:
   for policy in ['fraction_20pct','fixed_original_capacity']:
    for order in ([1,2] if cohort==PRIMARY else [1]):
     rr=[r for r in contrasts if r['cohort']==cohort and r['task']==task and r['model']==model and r['baseline']=='length_low' and r['budget_policy']==policy and r['order']==order]
     record={k:rr[0][k] for k in ['cohort','task','model','baseline','order','budget_policy']}
     record.update(cases=len(rr),remaining_n=rr[0]['n'],remaining_K_min=min(r['K'] for r in rr),remaining_K_max=max(r['K'] for r in rr))
     for metric in ['positive_hits','precision','pooled_AUROC','macro_within_family_AUROC']:
      key=metric+'_difference';vals=[r[key] for r in rr if finite(r[key])]
      fm=next(r for r in original if r['cohort']==cohort and r['task']==task and r['method']==model)[metric]
      fb=next(r for r in original if r['cohort']==cohort and r['task']==task and r['method']=='length_low')[metric]
      record.update({metric+'_full':fm-fb,metric+'_min':min(vals) if vals else NAN,metric+'_max':max(vals) if vals else NAN,metric+'_valid':len(vals),metric+'_positive_cases':sum(sign(x)==1 for x in vals),metric+'_zero_cases':sum(sign(x)==0 for x in vals),metric+'_negative_cases':sum(sign(x)==-1 for x in vals),metric+'_min_case':min(rr,key=lambda r:r[key] if finite(r[key]) else math.inf)['deletion_case'] if vals else '',metric+'_max_case':max(rr,key=lambda r:r[key] if finite(r[key]) else -math.inf)['deletion_case'] if vals else ''})
     summaries.append(record)
write('Table_S14_named_comparator_deletion_summary.tsv',summaries)
write('Fig_S27_primary_deletion_contrasts.tsv',[r for r in contrasts if r['cohort']==PRIMARY and r['baseline']=='length_low' and r['budget_policy']=='fraction_20pct'])

# Historical block composition and exact fixed-classification single-block deletion.
hist=read('historical_members.tsv.gz');assert len(hist)==29104
DATASETS=['AMPlify','tsAMP_I','c_AMPs_benchmark_resplit','HMD_AMP','AmPEP_raw_source','ampir_raw_mature90']
assert set(r['dataset'] for r in hist)==set(DATASETS)
assert len({r['sequence_id'] for r in hist})==28481
STRATA=[('all',None,None),('10-29',10,29),('30-59',30,59),('60-99',60,99),('100-126',100,126)]
histcomp=[];histinfl=[];historyfull=[];groupsroster=[]

def from_conf(c):
 tp,fn,fp,tn=c;P=tp+fn;N=fp+tn
 den=(tp+fp)*(tp+fn)*(tn+fp)*(tn+fn)
 mcc=(tp*tn-fp*fn)/math.sqrt(den) if den else (0. if P and N else NAN)
 return {'MCC':mcc,'recall':ratio(tp,P),'FPR':ratio(fp,N)}

with io.TextIOWrapper(gzip.GzipFile(filename=OUT/'tables/historical_single_block_deletions.tsv.gz',mode='wb',mtime=0),encoding='utf8',newline='') as stream:
 writer=None
 for dataset in DATASETS:
  allr=[r for r in hist if r['dataset']==dataset]
  for stratum,lo,hi in STRATA:
   rr=allr if lo is None else [r for r in allr if lo<=int(r['length'])<=hi]
   n=len(rr);P=sum(int(r['label']) for r in rr);N=n-P
   for grouping in ['global_group','local_group']:
    gg=defaultdict(list)
    for r in rr:gg[r[grouping]].append(r)
    sizes=[len(v) for v in gg.values()];ps=[sum(int(r['label']) for r in v) for v in gg.values()];ns=[len(v)-sum(int(r['label']) for r in v) for v in gg.values()]
    histcomp.append(dict(dataset=dataset,stratum=stratum,grouping=grouping,n=n,positive=P,negative=N,groups=len(gg),positive_groups=sum(x>0 for x in ps),negative_groups=sum(x>0 for x in ns),mixed_groups=sum(p>0 and nn>0 for p,nn in zip(ps,ns)),singletons=sum(x==1 for x in sizes),min_group=min(sizes) if sizes else 0,median_group=q(sizes,.5),p95_group=q(sizes,.95),max_group=max(sizes) if sizes else 0,largest_record_share=ratio(max(sizes),n) if sizes else NAN,largest_positive_share=ratio(max(ps),P) if sizes else NAN,largest_negative_share=ratio(max(ns),N) if sizes else NAN))
    if grouping!='global_group':continue
    for g,rows in gg.items():
     p=sum(int(r['label']) for r in rows)
     groupsroster.append(dict(dataset=dataset,stratum=stratum,group=g,n=len(rows),positive=p,negative=len(rows)-p))
    for model in MODELS:
     counts=defaultdict(lambda:[0,0,0,0]);total=[0,0,0,0]
     for r in rr:
      y=int(r['label']);pred=int(r[model+'__prediction']);i=(0 if pred else 1) if y else (2 if pred else 3)
      total[i]+=1;counts[r['global_group']][i]+=1
     full=from_conf(total)
     historyfull.append(dict(dataset=dataset,stratum=stratum,model=model,n=n,positive=P,negative=N,groups=len(gg),TP=total[0],FN=total[1],FP=total[2],TN=total[3],**full))
     values=[]
     for g,c in counts.items():
      remain=[a-b for a,b in zip(total,c)];v=from_conf(remain)
      row=dict(dataset=dataset,stratum=stratum,model=model,deleted_group=g,removed_n=sum(c),remaining_n=sum(remain),remaining_positive=remain[0]+remain[1],remaining_negative=remain[2]+remain[3],**v)
      if writer is None:writer=csv.DictWriter(stream,fieldnames=list(row),delimiter='\t',lineterminator='\n');writer.writeheader()
      writer.writerow(row);values.append(row)
     out=dict(dataset=dataset,stratum=stratum,model=model,n=n,groups=len(gg),deleted_cases=len(values))
     for key in ['MCC','recall','FPR']:
      valid=[v for v in values if finite(v[key])]
      out.update({key+'_full':full[key],key+'_min':min(v[key] for v in valid) if valid else NAN,key+'_max':max(v[key] for v in valid) if valid else NAN,key+'_valid_cases':len(valid),key+'_undefined_cases':len(values)-len(valid),key+'_max_abs_change':max(abs(v[key]-full[key]) for v in valid) if valid and finite(full[key]) else NAN})
     valid=[v for v in values if finite(v['MCC'])]
     out['largest_MCC_change_deleted_group']=max(valid,key=lambda v:abs(v['MCC']-full['MCC']))['deleted_group'] if valid and finite(full['MCC']) else ''
     histinfl.append(out)
write('Table_S13_historical_group_composition.tsv',histcomp)
write('historical_global_group_roster.tsv.gz',groupsroster)
write('historical_full_confusion_metrics.tsv',historyfull)
write('historical_single_block_deletion_summary.tsv',histinfl)

qa={'input_hashes_verified':True,'experimental_points_verified_against_formal':len(original),'family_AUROCs_verified_against_formal':len(contributions),'family_block_partition_equality':audit,'all_48_named_original_hit_differences_retained':True,'single_block_cases_per_task':36,'primary_two_block_cases_per_task':45,'deletion_method_rows':len(deletions),'all_six_control_paired_rows':len(contrasts),'historical_records':len(hist),'historical_unique_sequences':len({r['sequence_id'] for r in hist}),'historical_composition_rows':len(histcomp),'historical_model_stratum_summaries':len(histinfl),'new_bootstrap':False,'new_model_inference':False,'new_grouping':False,'all_checks_passed':True}
assert len(original)==96 and len(contributions)==864 and len(deletions)==3888 and len(contrasts)==11664
assert len(histcomp)==60 and len(histinfl)==180
assert next(r for r in historyfull if r['dataset']=='AmPEP_raw_source' and r['stratum']=='all' and r['model']=='Macrel')['MCC']==1
for d,expected in [('c_AMPs_benchmark_resplit',.144),('AmPEP_raw_source',.009)]:
 assert abs(next(r for r in historyfull if r['dataset']==d and r['stratum']=='all' and r['model']=='ampir')['MCC']-expected)<.0006
(OUT/'qa/numerical_QA.json').write_text(json.dumps(qa,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps(qa,ensure_ascii=False,indent=2))
print('PRIMARY REFERENCE, 20% budget:')
for r in summaries:
 if r['cohort']==PRIMARY and r['task']==TASKS[1] and r['budget_policy']=='fraction_20pct':
  print(r['model'],'delete',r['order'],'full',r['positive_hits_full'],'range',r['positive_hits_min'],r['positive_hits_max'],'signs +/0/-',r['positive_hits_positive_cases'],r['positive_hits_zero_cases'],r['positive_hits_negative_cases'],'family-delta',r['macro_within_family_AUROC_full'],r['macro_within_family_AUROC_min'],r['macro_within_family_AUROC_max'])
print('PRIMARY COMPOSITION',json.dumps([r for r in composition if r['cohort']==PRIMARY],ensure_ascii=False))
