"""Independent boundary-score and pair-enumeration checks for deletion analyses."""
from pathlib import Path
from collections import defaultdict
from fractions import Fraction
import csv,gzip,json,math,sys

OUT=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).resolve().parent
def read(folder,name):
 op=gzip.open if name.endswith('.gz') else open
 with op(OUT/folder/name,'rt',encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f,delimiter='\t'))
desc={r['sequence_id']:r for r in read('inputs','descriptor_values.tsv')}
score={(r['sequence_id'],r['model']):float(r['score']) for r in read('inputs','scores151.tsv')}
member=read('inputs','endpoint_membership.tsv')
sets={(r['cohort'],r['task'],r['deletion_case']):r for r in read('tables','deletion_sets_and_members.tsv')}
rows=read('tables','all_deletion_method_points.tsv')
def equal(a,b):return (math.isnan(a) and math.isnan(b)) or abs(a-b)<1e-10
def pair_auc(y,s):
 pos=[s[i] for i,v in enumerate(y) if v==1];neg=[s[i] for i,v in enumerate(y) if v==0]
 return sum((a>b)+.5*(a==b) for a in pos for b in neg)/(len(pos)*len(neg)) if pos and neg else float('nan')
for row in rows:
 ds=sets[row['cohort'],row['task'],row['deletion_case']]
 keep=set(ds['remaining_records'].split('|'))
 rr=[r for r in member if r['cohort']==row['cohort'] and r['task']==row['task'] and r['record_id'] in keep]
 assert len(rr)==int(row['n']) and sum(int(r['label']) for r in rr)==int(row['positive'])
 K=int(row['K']);method=row['method'];y=[int(r['label']) for r in rr]
 s=[score[r['sequence_id'],method] if (r['sequence_id'],method) in score else float(desc[r['sequence_id']][method]) for r in rr]
 cutoff=sorted(s,reverse=True)[K-1]
 higher=[i for i,x in enumerate(s) if x>cutoff];ties=[i for i,x in enumerate(s) if x==cutoff]
 hits=Fraction(sum(y[i] for i in higher))+Fraction(K-len(higher),len(ties))*sum(y[i] for i in ties)
 assert equal(float(hits),float(row['positive_hits']))
 assert equal(pair_auc(y,s),float(row['pooled_AUROC']))
 fv=[]
 for fam in {r['family'] for r in rr}:
  ix=[i for i,r in enumerate(rr) if r['family']==fam]
  fa=pair_auc([y[i] for i in ix],[s[i] for i in ix])
  if math.isfinite(fa):fv.append(fa)
 assert equal(sum(fv)/len(fv) if fv else float('nan'),float(row['macro_within_family_AUROC']))

# Independent direct record filtering for each historical maximum-influence deletion.
hist=read('inputs','historical_members.tsv.gz')
hs=read('tables','historical_single_block_deletion_summary.tsv')
checked=0
for r in hs:
 if not r['largest_MCC_change_deleted_group']:continue
 rr=[x for x in hist if x['dataset']==r['dataset'] and x['global_group']!=r['largest_MCC_change_deleted_group']]
 if r['stratum']!='all':
  lo,hi=map(int,r['stratum'].split('-'));rr=[x for x in rr if lo<=int(x['length'])<=hi]
 y=[int(x['label']) for x in rr];p=[int(x[r['model']+'__prediction']) for x in rr]
 tp=sum(a==1 and b==1 for a,b in zip(y,p));tn=sum(a==0 and b==0 for a,b in zip(y,p));fp=sum(a==0 and b==1 for a,b in zip(y,p));fn=sum(a==1 and b==0 for a,b in zip(y,p))
 den=(tp+fp)*(tp+fn)*(tn+fp)*(tn+fn)
 val=(tp*tn-fp*fn)/math.sqrt(den) if den else (0. if tp+fn and tn+fp else float('nan'))
 change=abs(val-float(r['MCC_full']))
 assert equal(change,float(r['MCC_max_abs_change']))
 checked+=1
result={'all_deletion_points_independent_boundary_tie_hit_check':len(rows),'all_deletion_pooled_AUROCs_direct_pair_check':len(rows),'all_deletion_family_AUROCs_direct_pair_check':len(rows),'historical_max_influence_deletions_independently_filtered':checked,'exact_fractional_tie_weights':True,'passed':True}
(OUT/'qa/independent_numerical_QA.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps(result,ensure_ascii=False,indent=2))
